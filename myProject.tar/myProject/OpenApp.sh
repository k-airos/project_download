#!/bin/bash
cd ./Scripts
source env/bin/activate
python ./guiMain.py
deactivate

